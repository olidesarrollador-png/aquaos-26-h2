#!/usr/bin/env bash
iso_name="aquaos"
iso_label="AQUAOS_26H2"
iso_publisher="Quack Labs <https://example.invalid/aquaos>"
iso_application="AquaOS 26 H2 Live/Install Environment"
iso_version="26H2"
install_dir="aquaos"
 bootmodes=('bios.syslinux.mbr' 'bios.syslinux.eltorito' 'uefi-ia32.grub.esp' 'uefi-x64.grub.esp')
arch="x86_64"
airootfs_image_type="squashfs"
