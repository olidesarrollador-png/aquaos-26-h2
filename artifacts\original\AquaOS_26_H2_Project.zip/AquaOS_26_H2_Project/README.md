# AquaOS 26 H2 — proyecto inicial

AquaOS es un proyecto de sistema operativo basado en Arch Linux para equipos x86_64.

Este paquete contiene un **perfil inicial de Archiso** y scripts de personalización. No es todavía una ISO compilada ni un instalador gráfico terminado: la ISO se construye desde un entorno Arch Linux y debe probarse primero en una máquina virtual.

## Decisiones incluidas

- Base: Arch Linux (rolling release).
- Escritorio inicial: KDE Plasma, personalizable con identidad AquaOS.
- Navegador predeterminado: Google Chrome (se instala desde AUR mediante `google-chrome`).
- Steam y herramientas gaming.
- Ollama instalado, **sin descargar ni incluir modelos**.
- Terminal, Dolphin, VLC y LibreOffice.
- Sin agente de IA propio, sin chatbot y sin modelos preinstalados.

## Requisitos para construir la ISO

Usa un ordenador o máquina virtual con Arch Linux x86_64, conexión a Internet y permisos `sudo`. Necesitarás espacio libre suficiente para paquetes y la ISO.

```bash
sudo pacman -Syu --needed archiso git
git clone <TU_REPOSITORIO>
cd AquaOS_26_H2_Project
sudo mkarchiso -v -w work -o out profile
```

La ISO aparecerá en `out/`. Arranca primero en VirtualBox, VMware o QEMU. No la instales directamente en tu ordenador principal sin probarla.

## Instalación en disco

El entorno live incluye `archinstall`, una herramienta de instalación guiada de Arch Linux. En esta primera versión se usa como instalador funcional de base; todavía no es el instalador gráfico propio de AquaOS que diseñaremos más adelante.

Desde el escritorio live, abre una terminal y ejecuta:

```bash
sudo archinstall
```

Después del primer arranque en el sistema instalado, ejecuta:

```bash
sudo /usr/local/bin/aquaos-first-boot
```

El script configura el branding inicial y ofrece instalar Google Chrome desde AUR. No descarga modelos de Ollama.

## Avisos importantes

- Arch Linux es una distribución rolling release: las actualizaciones pueden cambiar componentes.
- Steam requiere controladores gráficos adecuados y bibliotecas de 32 bits.
- Google Chrome es software propietario de Google; el paquete se obtiene mediante AUR, no se redistribuye dentro de este proyecto.
- Ollama se instala como aplicación/servicio, pero no se descarga ningún modelo.
- La compatibilidad NVIDIA/AMD/Intel debe validarse en hardware real.
- Los objetivos de RAM son metas de optimización, no garantías.

## Próximos hitos

1. Compilar y probar la ISO live.
2. Validar instalación en VM y hardware real.
3. Crear tema, logotipo, fondos y configuración de Aqua Desktop.
4. Sustituir `archinstall` por un instalador gráfico AquaOS basado en Calamares cuando esté empaquetado y probado.
5. Crear imágenes separadas para Pro, Server, TSC y Educative.
