#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PKG="$ROOT/profile/packages.x86_64"
if grep -Eq '^[[:space:]]*( konsole| fwupd)$' "$PKG"; then
  echo "Hay entradas de paquetes con espacios iniciales."
  exit 1
fi
for p in base linux linux-firmware archinstall plasma-desktop steam ollama; do
  grep -qx "$p" "$PKG" || { echo "Falta paquete requerido: $p"; exit 1; }
done
echo "Perfil AquaOS básico: comprobación correcta."
