#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v mkarchiso >/dev/null 2>&1; then
  echo "Falta archiso. Instala con: sudo pacman -S archiso"
  exit 1
fi
sudo mkarchiso -v -w work -o out profile
